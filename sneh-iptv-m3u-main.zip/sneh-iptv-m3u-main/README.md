<p align="center"><img src="images/snehiptv.gif" width="350" height="220"></p>
<h1 align="center"> ✯ Sneh IPTV v4.0 ✯ </h1>

<p align="center"><b>Here You Can get all Live Streaming Movies Musics Sports Wildlife etc Channels URL's and Direct Play Anywhere</b></p><br>

<p align="center">🔕 Sneh IPTV Weekly Update 🔕 <br> On Sunday Only</p><br>

<p align="center">🔕 BIG NOTICE :  🔕 <BR> I'M OFFLINE ONLY FOR THIS MONTH NEXT UPDATE FROM NEXT MONTH . <BR> BE PATIENCE 🥰. NEW SURPRISE 🤹‍♂️ IN DECEMBER .</p><br>

<h2>🤹‍♂️ Join Our Discord Server :</h2>
- Join Now : https://bit.ly/discord-techiesneh  <br>

<h2> 🍃 Updates v4.0 : </h2>
 
<h4>

1 » Worldwide Channels Added<br>
2 » All Indian Channels Works<br>
3 » Some Channels not Works<br>
4 » Zee5, Voot, MX , SunNxt & Sony Channels Updated<br>
5 » New Indian Channels Added<br>
6 » Indian Radio Channels Added<br>
7 » Indian Movies Playlists Added<br> 
8 » Update your M3U files weekly from here<br>

</h4>

<br> 

<h2>🧑‍💻 You Can Also Watch Here :</h2>
- Our Site : https://snehiptv.netlify.app  <br>

<h2> 📙 Playlists Links : </h2>

<p align="left"><img src="https://i.ibb.co/5BsHSxF/20210806-125945.png" width="100" height="100"></p>

### TechieSneh IPTV+ v4.0 [aLL LInKs UpDaTed]
• JioTv, Zee5, SunNxt, MX Play & Sony Channels Added<br>
• Worlds Channels Added <br>
• All In One IPTV : https://bit.ly/snehiptv <img src="images/new.gif" width="25" height="25"> Sneh All IPTV+ v4.0  <br>
• Right click on m3u playlists to copy and play in Tivimate App<br>
• Click On Channels Which You Want to Play<br>
• And Just Enjoy
 
<hr><br>
<p align="left"><img src="images/india.gif" width="100" height="50"></p>

### Indian Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/TataSky%20Playlists/sneh-tatasky-plus.m3u"><img src="images/new.gif" width="25" height="25"> Sneh India </a>  <br>
• 2nd Link : <img src="images/new.gif" width="25" height="25"> https://bit.ly/snehiptvweekly <br> 
• 3rd Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Indian%20Playlists/sneh-airteltv.m3u"><img src="images/new.gif" width="25" height="25">  Sneh AirtelTV Updated </a>  <br><br> 


<p align="left"><img src="images/nick.gif" width="150" height="50"></p>

### Kids Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Indian%20Playlists/sneh-kids.m3u"><img src="images/new.gif" width="25" height="25"> Sneh Kids Playlist</a>  <br><br>


<p align="left"><img src="images/sports.gif" width="100" height="50"></p>

### Sports Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Indian%20Playlists/sneh-sports.m3u"><img src="images/new.gif" width="25" height="25"> Sneh Sports Playlist</a>  <br><br>


<p align="left"><img src="images/zee5.png" width="38" height="38"><img src="images/sony.gif" width="50" height="50"></p>

### Zee5, Sony, SunNxt, MX & Voot Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Zee5%20%26%20Sony%20Playlists/sneh-z5-sony.m3u">Sneh Sony & Zee5 Playlists </a><br>
• 2nd Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Zee5%20%26%20Sony%20Playlists/sneh-sonyliv.m3u">Sneh Sony Playlists </a><br>
• 3rd Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Zee5%20%26%20Sony%20Playlists/sneh-mxtv.m3u">Sneh MxPlayer Playlists </a><br>
• 4th Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Zee5%20%26%20Sony%20Playlists/sneh-voot.m3u">Sneh Voot Playlists </a><br>
• 5th Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Zee5%20%26%20Sony%20Playlists/sneh-sunnxt.m3u">Sneh SunNxt Playlists </a><br><br>
 
<p align="left"><img src="images/tamil.gif" width="50" height="50"><img src="images/zeetamil.png" width="40" height="40"></p>

### Tamil Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Tamil%20Playlists/sneh-cloudtamil.m3u">Sneh Cloud Tamil Playlists </a>  <br>
• 2nd Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Tamil%20Playlists/sneh-tamil.m3u"> <img src="images/new.gif" width="25" height="25"> Sneh Tamil Playlists </a>  <br><br>
 
 
<p align="left"><img src="images/telugu.png" width="45" height="35"><img src="images/telugu1.png" width="35" height="35"></p>

### Telugu Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Telugu%20Playlists/sneh-telugu.m3u"> <img src="images/new.gif" width="25" height="25"> Sneh Telugu Playlists </a>  <br><br>

<p align="left"><img src="images/punjabi.gif" width="100" height="50"></p>

### Punjabi Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Indian%20Playlists/sneh-punjabi.m3u"><img src="images/new.gif" width="25" height="25"> Sneh Punjabi Playlist</a>  <br><br>


<p align="left"><img src="images/suryatv.png" width="50" height="50"></p>

### Malayalam Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Indian%20Playlists/sneh-malayalam.m3u"><img src="images/new.gif" width="25" height="25"> Sneh Malayalam Playlist</a>  <br><br>


<p align="left"><img src="images/zeekannada.png" width="100" height="50"></p>

### Kannada Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Indian%20Playlists/sneh-kannada.m3u"><img src="images/new.gif" width="25" height="25"> Sneh Kannada Playlist</a>  <br><br>



<p align="left"><img src="images/movies.gif" width="100" height="50"></p>

### Indian Movies Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Indian%20Playlists/sneh-allmovies.m3u"><img src="images/new.gif" width="25" height="25"> Sneh ALL Movies Playlist</a>  <br>


<p align="left"><img src="images/world.gif" width="100" height="50"></p>

### World Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/World%20Playlists/sneh-all-worldtv.m3u">All World Playlists </a>  <br>
• 2nd Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/World%20Playlists/sneh-usa-tv.m3u">USA Channels Playlists </a>  <br>
• 3rd Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/World%20Playlists/sneh-worldtv-eng.m3u">Eng World Channels Playlists </a>  <br>

<p align="left"><img src="images/radio.gif" width="100" height="50"></p>

### Indian Radio Playlists

• 1st Link : <a href="https://raw.githubusercontent.com/techiesneh/sneh-iptv-m3u/main/Radio%20Playlists/sneh-radio.m3u">Radio Playlists </a>  <br><br>


<h2>🤹‍♂️ Join Our Discord Server :</h2>
- Join Now : https://bit.ly/discord-techiesneh  <br>

<h2> 📚 IPTV Player Apps Collections : </h2>

 
#### 📽 Tivimate Premium v2.8.0[Best]

• Download <a href="https://files.moddroid.com/TiviMate%20IPTV%20Player/_TiviMate_2.8.0_Premium.apk">Tivimate Pro v2.8.0</a> to Play Live Channels<br><br>
• Play in Tivimate App<br><br>

#### 📺 IPTVNator v8.0 ( FOR PC )

• Download <a href="https://github.com/4gray/iptvnator/releases/download/v0.8.0/iptvnator-Setup-0.8.0.exe">IPTVNator v8.0</a> to Play Live Channels<br><br>
• Also Play in IPTVNator App<br><br>

#### 🎶 IPTV Smarters Pro v3.1.2[Updated]

• Download <a href="https://files.moddroid.co/IPTV%20Smarters%20Pro/IPTV_Smarters_Pro_v3.1.2_-_Mod_-_All_In_One.apk">IPTV Smarters Pro v3.1.2</a> to Play Live Channels<br><br>
• Also Play in IPTV Smarters App<br><br>

#### 🎥 OTT Navigator Pro v1.6.5

• Download <a href="https://files.moddroid.co/OTT%20Navigator%20IPTV/OTT_NAVIGATOR_1.6.5.5_MustHave.apk">OTT Navigator Pro v1.6.5</a> to Play Live Channels<br><br>
• Also Play in OTT Navigator App<br><br>

#### 📽 IPTV Pro v6.1.10[Updated]

• Download <a href="https://files.moddroid.co/IPTV%20Pro/IPTV_Pro-v6.1.10_build_1102-Mod-armeabi-v7a.apk">IPTV Pro v6.1.10</a> to Play Live Channels<br><br>
• Also Play in IPTV Pro App<br><br>

#### 📺 IPTV Extreme Pro v113

• Download <a href="https://files.moddroid.co/IPTV%20Extreme%20Pro/IPTV_Extrme_Pro_113.apk">IPTV Extreme Pro v113</a> to Play Live Channels<br><br>
• Also Play in IPTV Extreme Pro App<br><br>

---

</h4>
<br>

<h2>🧑‍💻 You Can Also Watch Here :</h2>
- Our Site : https://snehiptv.netlify.app  <br>

<h2> 🍁 Given Below Are List of Some Screenshots Of Sneh IPTV : </h2>


<div>

<img src="images/iptv1.jpg" alt="IPTV 1" width="320" height="180">
<img src="images/iptv2.jpg" alt="IPTV 2" width="320" height="180"><br>
<img src="images/iptv3.jpg" alt="IPTV 3" width="320" height="180">
<img src="images/iptv4.jpg" alt="IPTV 4" width="320" height="180"><br>
<img src="images/iptv5.jpg" alt="IPTV 5" width="320" height="180">

</div>

<br> 

<h3> 🎫 Licence : </h3>
Apache 2.0 © Techie Sneh<br>

<h3> ✉️ Contact Us : </h3>
[Techie Sneh](https://telegram.me/techiesneh)

<h4> Star ✨ This Repo if you Liked 👌 it ⭐⭐⭐ </h4>

---
<h5 align='center'>© 2021 Techie Sneh</h5>
